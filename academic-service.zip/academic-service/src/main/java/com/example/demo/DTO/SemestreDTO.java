package com.example.demo.DTO;

public class SemestreDTO {
	private String nombresem;

	public SemestreDTO() {
		
	}

	public SemestreDTO(String nombresem) {
		this.nombresem = nombresem;
	}

	public String getNombresem() {
		return nombresem;
	}

	public void setNombresem(String nombresem) {
		this.nombresem = nombresem;
	}

}
