package com.example.demo.DTO;

public class FacutadDTO {
	private String nombrefac;

	public FacutadDTO() {
		
	}

	public FacutadDTO(String nombrefac) {
		this.nombrefac = nombrefac;
	}

	public String getNombrefac() {
		return nombrefac;
	}

	public void setNombrefac(String nombrefac) {
		this.nombrefac = nombrefac;
	}
	
}
