package com.example.demo.DTO;

public class TipoProDTO {
	
	private String tipo;
	public TipoProDTO() {
		
	}
	public TipoProDTO(String tipo) {
		this.tipo = tipo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
}
